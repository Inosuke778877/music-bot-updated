export default {
    name: 'interactionCreate',
    execute(interaction, client) {
        // For future slash commands implementation
        if (!interaction.isCommand()) return;
    }
};
